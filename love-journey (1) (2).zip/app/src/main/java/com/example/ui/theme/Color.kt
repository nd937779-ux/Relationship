package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Romantic Palette based on user's theme (#ff4b6e, #fff0f3)
val LovePinkPrimary = Color(0xFFFF4B6E)
val LovePinkVariant = Color(0xFFFF758C)
val LovePinkDark = Color(0xFFD81B60)
val LovePinkLight = Color(0xFFFF8DA1)
val LoveSoftBg = Color(0xFFFFF0F3)
val LoveCardBg = Color(0xFFFFFFFF)
val LoveTextDark = Color(0xFF333333)
val LoveTextMuted = Color(0xFF777777)

// Dark mode tokens based on user CSS:
// --bg: #121212; --card-bg: #1e1e1e; --text: #f1f1f1; --sub: #aaaaaa;
val LoveBgDark = Color(0xFF121212)
val LoveCardBgDark = Color(0xFF1E1E1E)
val LoveTextDarkTheme = Color(0xFFF1F1F1)
val LoveTextMutedDark = Color(0xFFAAAAAA)

// Material 3 Light Color Scheme
val PrimaryLight = Color(0xFFFF4B6E)
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFFFD9E2)
val OnPrimaryContainerLight = Color(0xFF3F0015)

val SecondaryLight = Color(0xFFFF758C)
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFFFD9E2)
val OnSecondaryContainerLight = Color(0xFF3F0015)

val BackgroundLight = Color(0xFFFFF0F3)
val OnBackgroundLight = Color(0xFF333333)
val SurfaceLight = Color(0xFFFFFFFF)
val OnSurfaceLight = Color(0xFF333333)
val SurfaceVariantLight = Color(0xFFFFF0F3)
val OnSurfaceVariantLight = Color(0xFF777777)
val OutlineLight = Color(0xFFCCCCCC)

// Material 3 Dark Color Scheme
val PrimaryDark = Color(0xFFFF4B6E)
val OnPrimaryDark = Color(0xFFFFFFFF)
val PrimaryContainerDark = Color(0xFF4A1220)
val OnPrimaryContainerDark = Color(0xFFFFD9E2)

val SecondaryDark = Color(0xFFFF758C)
val OnSecondaryDark = Color(0xFF121212)
val SecondaryContainerDark = Color(0xFF401822)
val OnSecondaryContainerDark = Color(0xFFFFD9E2)

val BackgroundDark = Color(0xFF121212)
val OnBackgroundDark = Color(0xFFF1F1F1)
val SurfaceDark = Color(0xFF1E1E1E)
val OnSurfaceDark = Color(0xFFF1F1F1)
val SurfaceVariantDark = Color(0xFF282828)
val OnSurfaceVariantDark = Color(0xFFAAAAAA)
val OutlineDark = Color(0xFF444444)
