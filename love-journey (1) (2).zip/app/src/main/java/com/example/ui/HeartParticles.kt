package com.example.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.launch
import kotlin.random.Random

private data class HeartParticle(
    val id: Int,
    val startX: Float,
    val size: Float,
    val color: Color,
    val anim: Animatable<Float, *>
)

@Composable
fun HeartShowerOverlay(
    showerEvent: SharedFlow<Unit>,
    modifier: Modifier = Modifier
) {
    val particles = remember { mutableStateListOf<HeartParticle>() }
    var particleCounter by remember { mutableStateOf(0) }

    LaunchedEffect(showerEvent) {
        showerEvent.collect {
            // Spawn 18 lovely hearts
            val colors = listOf(
                Color(0xFFFF4B6E),
                Color(0xFFFF758C),
                Color(0xFFFF8DA1),
                Color(0xFFFFB1C2),
                Color(0xFFFFD1DC)
            )

            repeat(18) {
                val newId = particleCounter++
                val anim = Animatable(0f)
                val particle = HeartParticle(
                    id = newId,
                    startX = Random.nextFloat(),
                    size = Random.nextFloat() * 24f + 20f,
                    color = colors[Random.nextInt(colors.size)],
                    anim = anim
                )
                particles.add(particle)

                launch {
                    anim.animateTo(
                        targetValue = 1f,
                        animationSpec = tween(
                            durationMillis = Random.nextInt(1400, 2200),
                            easing = FastOutSlowInEasing
                        )
                    )
                    particles.remove(particle)
                }
            }
        }
    }

    if (particles.isNotEmpty()) {
        Canvas(modifier = modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            particles.forEach { particle ->
                val progress = particle.anim.value
                val y = height * (1f - progress * 1.1f)
                val drift = kotlin.math.sin(progress * 6f) * 40f
                val x = particle.startX * width + drift
                val alpha = (1f - progress).coerceIn(0f, 1f)

                drawHeart(
                    center = Offset(x, y),
                    size = particle.size,
                    color = particle.color.copy(alpha = alpha)
                )
            }
        }
    }
}

private fun DrawScope.drawHeart(center: Offset, size: Float, color: Color) {
    val path = Path().apply {
        val halfSize = size / 2
        moveTo(center.x, center.y + halfSize * 0.7f)
        cubicTo(
            center.x - size, center.y - halfSize * 0.5f,
            center.x - halfSize * 0.5f, center.y - size,
            center.x, center.y - halfSize * 0.3f
        )
        cubicTo(
            center.x + halfSize * 0.5f, center.y - size,
            center.x + size, center.y - halfSize * 0.5f,
            center.x, center.y + halfSize * 0.7f
        )
        close()
    }
    drawPath(path = path, color = color)
}
