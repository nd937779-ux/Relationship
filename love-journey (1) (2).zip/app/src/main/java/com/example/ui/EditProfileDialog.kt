package com.example.ui

import android.app.DatePickerDialog
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ProfileEntity
import com.example.util.TimeUtils
import java.util.Calendar

@Composable
fun EditProfileDialog(
    currentProfile: ProfileEntity,
    onDismiss: () -> Unit,
    onSave: (
        partner1: String,
        partner1Age: Int,
        partner1Birthday: String,
        partner1Address: String,
        partner2: String,
        partner2Age: Int,
        partner2Birthday: String,
        partner2Address: String,
        startDateMillis: Long,
        status: String,
        note: String
    ) -> Unit
) {
    val context = LocalContext.current
    var selectedSection by remember { mutableIntStateOf(0) }

    // Partner 1 state
    var p1Name by remember { mutableStateOf(currentProfile.partner1) }
    var p1AgeStr by remember { mutableStateOf(currentProfile.partner1Age.toString()) }
    var p1Birthday by remember { mutableStateOf(currentProfile.partner1Birthday) }
    var p1Address by remember { mutableStateOf(currentProfile.partner1Address) }

    // Partner 2 state
    var p2Name by remember { mutableStateOf(currentProfile.partner2) }
    var p2AgeStr by remember { mutableStateOf(currentProfile.partner2Age.toString()) }
    var p2Birthday by remember { mutableStateOf(currentProfile.partner2Birthday) }
    var p2Address by remember { mutableStateOf(currentProfile.partner2Address) }

    // Relationship state
    var startDateMillis by remember { mutableLongStateOf(currentProfile.startDateMillis) }
    var coupleStatus by remember { mutableStateOf(currentProfile.coupleStatus) }
    var customNote by remember { mutableStateOf(currentProfile.customNote) }

    val calendar = remember(startDateMillis) {
        val cal = Calendar.getInstance()
        cal.timeInMillis = startDateMillis
        cal
    }

    val datePickerDialog = remember {
        DatePickerDialog(
            context,
            { _, year, month, dayOfMonth ->
                val newCal = Calendar.getInstance()
                newCal.set(year, month, dayOfMonth, 0, 0, 0)
                newCal.set(Calendar.MILLISECOND, 0)
                startDateMillis = newCal.timeInMillis
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        )
    }

    val sections = listOf("Partner 1", "Partner 2", "Anniversary")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Favorite,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(end = 8.dp)
                )
                Text("Edit Couple Profiles", style = MaterialTheme.typography.titleLarge)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ScrollableTabRow(
                    selectedTabIndex = selectedSection,
                    edgePadding = 0.dp,
                    modifier = Modifier.fillMaxWidth().testTag("edit_profile_tabs")
                ) {
                    sections.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedSection == index,
                            onClick = { selectedSection = index },
                            text = { Text(title, fontWeight = if (selectedSection == index) FontWeight.Bold else FontWeight.Normal) },
                            modifier = Modifier.testTag("tab_edit_$index")
                        )
                    }
                }

                when (selectedSection) {
                    0 -> {
                        // Partner 1 (e.g. Sajal Das)
                        OutlinedTextField(
                            value = p1Name,
                            onValueChange = { p1Name = it },
                            label = { Text("Name") },
                            placeholder = { Text("e.g. Sajal Das") },
                            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("partner1_name_input")
                        )

                        OutlinedTextField(
                            value = p1AgeStr,
                            onValueChange = { p1AgeStr = it.filter { ch -> ch.isDigit() } },
                            label = { Text("Age (Years)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("partner1_age_input")
                        )

                        OutlinedTextField(
                            value = p1Birthday,
                            onValueChange = { p1Birthday = it },
                            label = { Text("Birthday") },
                            placeholder = { Text("e.g. 10 January") },
                            leadingIcon = { Icon(Icons.Default.CalendarMonth, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("partner1_birthday_input")
                        )

                        OutlinedTextField(
                            value = p1Address,
                            onValueChange = { p1Address = it },
                            label = { Text("Address / Country") },
                            placeholder = { Text("e.g. India") },
                            leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("partner1_address_input")
                        )
                    }

                    1 -> {
                        // Partner 2 (e.g. Partner Name)
                        OutlinedTextField(
                            value = p2Name,
                            onValueChange = { p2Name = it },
                            label = { Text("Name") },
                            placeholder = { Text("e.g. Partner Name") },
                            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("partner2_name_input")
                        )

                        OutlinedTextField(
                            value = p2AgeStr,
                            onValueChange = { p2AgeStr = it.filter { ch -> ch.isDigit() } },
                            label = { Text("Age (Years)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("partner2_age_input")
                        )

                        OutlinedTextField(
                            value = p2Birthday,
                            onValueChange = { p2Birthday = it },
                            label = { Text("Birthday") },
                            placeholder = { Text("e.g. 15 August") },
                            leadingIcon = { Icon(Icons.Default.CalendarMonth, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("partner2_birthday_input")
                        )

                        OutlinedTextField(
                            value = p2Address,
                            onValueChange = { p2Address = it },
                            label = { Text("Address / Country") },
                            placeholder = { Text("e.g. India") },
                            leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("partner2_address_input")
                        )
                    }

                    2 -> {
                        // Anniversary & Motto
                        Column {
                            Text(
                                "Relationship Start Date",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.outline
                            )
                            Spacer(Modifier.height(4.dp))
                            OutlinedButton(
                                onClick = { datePickerDialog.show() },
                                modifier = Modifier.fillMaxWidth().testTag("select_start_date_button"),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(
                                    Icons.Default.CalendarMonth,
                                    contentDescription = null,
                                    modifier = Modifier.padding(end = 8.dp)
                                )
                                Text(TimeUtils.formatDate(startDateMillis))
                            }
                        }

                        OutlinedTextField(
                            value = coupleStatus,
                            onValueChange = { coupleStatus = it },
                            label = { Text("Status / Motto") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("status_input")
                        )

                        OutlinedTextField(
                            value = customNote,
                            onValueChange = { customNote = it },
                            label = { Text("Special Promise / Note") },
                            maxLines = 2,
                            modifier = Modifier.fillMaxWidth().testTag("note_input")
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val p1Age = p1AgeStr.toIntOrNull() ?: 23
                    val p2Age = p2AgeStr.toIntOrNull() ?: 21
                    onSave(
                        p1Name,
                        p1Age,
                        p1Birthday,
                        p1Address,
                        p2Name,
                        p2Age,
                        p2Birthday,
                        p2Address,
                        startDateMillis,
                        coupleStatus,
                        customNote
                    )
                },
                modifier = Modifier.testTag("save_profile_button"),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Text("Save Changes")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_profile_button")
            ) {
                Text("Cancel")
            }
        }
    )
}
