package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Cake
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.PhotoAlbum
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.MemoryEntity
import com.example.data.VaultFolderEntity
import com.example.ui.theme.LovePinkDark
import com.example.ui.theme.LovePinkPrimary
import com.example.ui.theme.LovePinkVariant
import com.example.ui.theme.LoveSoftBg
import com.example.util.TimeUtils

// Custom dashed border modifier matching CSS: border: 2px dashed var(--secondary);
fun Modifier.dashedBorder(
    strokeWidth: Dp = 2.dp,
    color: Color = LovePinkVariant,
    cornerRadius: Dp = 12.dp,
    dashLength: Dp = 7.dp,
    gapLength: Dp = 5.dp
): Modifier = this.drawBehind {
    val stroke = Stroke(
        width = strokeWidth.toPx(),
        pathEffect = PathEffect.dashPathEffect(
            floatArrayOf(dashLength.toPx(), gapLength.toPx()),
            0f
        )
    )
    drawRoundRect(
        color = color,
        cornerRadius = CornerRadius(cornerRadius.toPx(), cornerRadius.toPx()),
        style = stroke
    )
}

@Composable
fun MomentsScreen(
    folders: List<VaultFolderEntity>,
    memories: List<MemoryEntity>,
    selectedFolder: String?,
    onSelectFolder: (String?) -> Unit,
    onOpenAddMoment: (String?) -> Unit,
    onOpenAddFolder: () -> Unit,
    onDeleteMoment: (MemoryEntity) -> Unit,
    onToggleFavorite: (Long, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    Box(modifier = modifier.fillMaxSize()) {
        if (selectedFolder == null) {
            // Main Folder Gallery View (Matching HTML: 📸 Yearly Memory Vault)
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("moments_screen_scroll"),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 100.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    // Container Card matching user HTML structure (<div id="memories" class="tab-content">)
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("memory_vault_container")
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            // Title: <h2>📸 Yearly Memory Vault</h2>
                            Text(
                                text = "📸 Yearly Memory Vault",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = LovePinkPrimary,
                                textAlign = TextAlign.Center,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 10.dp)
                                    .testTag("vault_title_text")
                            )

                            HorizontalDivider(
                                color = MaterialTheme.colorScheme.background,
                                thickness = 2.dp,
                                modifier = Modifier.padding(bottom = 16.dp)
                            )

                            // 2-Column Grid of Vault Folders (First Meet, Propose, Valentine, Birthdays)
                            val defaultFolderNames = listOf("First Meet", "Propose", "Valentine", "Birthdays")
                            val displayedFolders = if (folders.isEmpty()) {
                                defaultFolderNames.map { VaultFolderEntity(name = it) }
                            } else {
                                folders
                            }

                            // Pairs for 2-column grid inside LazyColumn
                            val chunkedFolders = displayedFolders.chunked(2)
                            chunkedFolders.forEach { rowFolders ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(bottom = 12.dp),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    rowFolders.forEach { folder ->
                                        val count = memories.count { it.folderName.equals(folder.name, ignoreCase = true) }
                                        VaultFolderCard(
                                            folder = folder,
                                            itemCount = count,
                                            onClick = {
                                                android.widget.Toast.makeText(
                                                    context,
                                                    "Opening ${folder.name} Folder...",
                                                    android.widget.Toast.LENGTH_SHORT
                                                ).show()
                                                onSelectFolder(folder.name)
                                            },
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                    if (rowFolders.size == 1) {
                                        Spacer(modifier = Modifier.weight(1f))
                                    }
                                }
                            }

                            Spacer(Modifier.height(8.dp))

                            // Quick Action Buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = { onOpenAddMoment(null) },
                                    modifier = Modifier.weight(1f).testTag("add_memory_btn"),
                                    colors = ButtonDefaults.buttonColors(containerColor = LovePinkPrimary),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Add Memory", fontSize = 13.sp)
                                }

                                OutlinedButton(
                                    onClick = onOpenAddFolder,
                                    modifier = Modifier.weight(1f).testTag("add_folder_btn"),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(Icons.Default.CreateNewFolder, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("New Folder", fontSize = 13.sp)
                                }
                            }
                        }
                    }
                }

                // Recent Memories Feed Preview
                item {
                    Text(
                        text = "✨ Recent Memories Timeline",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = LovePinkPrimary,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }

                items(memories.take(5), key = { it.id }) { memory ->
                    MemoryItemCard(
                        memory = memory,
                        onToggleFavorite = { onToggleFavorite(memory.id, memory.isFavorite) },
                        onDelete = { onDeleteMoment(memory) }
                    )
                }
            }
        } else {
            // Folder Detail View (Photo Moments for the specific folder)
            val folderMemories = memories.filter { it.folderName.equals(selectedFolder, ignoreCase = true) }

            Column(modifier = Modifier.fillMaxSize()) {
                // Header Bar with Back Button
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { onSelectFolder(null) },
                        modifier = Modifier.testTag("back_to_vault_btn")
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to Vault",
                            tint = LovePinkPrimary
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = selectedFolder,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = LovePinkPrimary
                        )
                        Text(
                            text = "📂 Yearly Archive • ${folderMemories.size} Moments",
                            fontSize = 12.sp,
                            color = Color(0xFF777777)
                        )
                    }

                    Button(
                        onClick = { onOpenAddMoment(selectedFolder) },
                        colors = ButtonDefaults.buttonColors(containerColor = LovePinkPrimary),
                        shape = RoundedCornerShape(18.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("add_to_folder_btn")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Add", fontSize = 12.sp)
                    }
                }

                if (folderMemories.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                Icons.Default.PhotoAlbum,
                                contentDescription = null,
                                tint = LovePinkVariant.copy(alpha = 0.5f),
                                modifier = Modifier.size(64.dp)
                            )
                            Spacer(Modifier.height(16.dp))
                            Text(
                                text = "No photos in '$selectedFolder' yet",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text = "Tap '+ Add' to save photos, sweet stories, and memories to this archive!",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("folder_memories_list"),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 100.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(folderMemories, key = { it.id }) { memory ->
                            MemoryItemCard(
                                memory = memory,
                                onToggleFavorite = { onToggleFavorite(memory.id, memory.isFavorite) },
                                onDelete = { onDeleteMoment(memory) }
                            )
                        }
                    }
                }
            }
        }
    }
}

// Vault Folder Card matching user HTML:
// .folder { background: var(--bg); border: 2px dashed var(--secondary); border-radius: 12px; padding: 15px; text-align: center; }
// .folder h3 { color: var(--primary); font-size: 14px; margin-bottom: 5px; }
// .folder p { font-size: 11px; color: var(--sub); }
@Composable
fun VaultFolderCard(
    folder: VaultFolderEntity,
    itemCount: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(LoveSoftBg)
            .dashedBorder(strokeWidth = 2.dp, color = LovePinkVariant, cornerRadius = 12.dp)
            .clickable { onClick() }
            .padding(15.dp)
            .testTag("vault_folder_${folder.name.lowercase().replace(" ", "_")}"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            // Folder Icon
            Icon(
                imageVector = getFolderIcon(folder.name),
                contentDescription = folder.name,
                tint = LovePinkPrimary,
                modifier = Modifier
                    .size(28.dp)
                    .padding(bottom = 4.dp)
            )

            // h3 { color: var(--primary); font-size: 14px; margin-bottom: 5px; }
            Text(
                text = folder.name,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = LovePinkPrimary,
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(3.dp))

            // p { font-size: 11px; color: var(--sub); }
            Text(
                text = folder.subtitle,
                fontSize = 11.sp,
                color = Color(0xFF777777),
                textAlign = TextAlign.Center
            )

            if (itemCount > 0) {
                Spacer(Modifier.height(4.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(LovePinkPrimary.copy(alpha = 0.15f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "$itemCount photos",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = LovePinkPrimary
                    )
                }
            }
        }
    }
}

@Composable
fun MemoryItemCard(
    memory: MemoryEntity,
    onToggleFavorite: () -> Unit,
    onDelete: () -> Unit
) {
    ElevatedCard(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("memory_item_card_${memory.id}")
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
            // Optional Attached Image (pre-populated drawable or custom URI)
            val drawableId = getDrawableId(memory.drawableResName)
            if (drawableId != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .padding(bottom = 10.dp)
                ) {
                    Image(
                        painter = painterResource(id = drawableId),
                        contentDescription = memory.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            } else if (!memory.imageUri.isNullOrEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .padding(bottom = 10.dp)
                ) {
                    AsyncImage(
                        model = memory.imageUri,
                        contentDescription = memory.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer)
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = memory.folderName,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }

                    if (memory.tag.isNotBlank()) {
                        Text(
                            text = "• ${memory.tag}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onToggleFavorite,
                        modifier = Modifier.size(32.dp).testTag("fav_btn_${memory.id}")
                    ) {
                        Icon(
                            imageVector = if (memory.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Favorite",
                            tint = if (memory.isFavorite) LovePinkPrimary else MaterialTheme.colorScheme.outline,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(32.dp).testTag("del_btn_${memory.id}")
                    ) {
                        Icon(
                            Icons.Default.Delete,
                            contentDescription = "Delete",
                            tint = MaterialTheme.colorScheme.outline,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Spacer(Modifier.height(6.dp))

            Text(
                text = memory.title,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(Modifier.height(2.dp))

            Text(
                text = TimeUtils.formatDate(memory.dateMillis),
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.outline
            )

            Spacer(Modifier.height(6.dp))

            Text(
                text = memory.description,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 18.sp
            )
        }
    }
}

private fun getFolderIcon(folderName: String): androidx.compose.ui.graphics.vector.ImageVector {
    return when (folderName.lowercase()) {
        "first meet" -> Icons.Default.Favorite
        "propose" -> Icons.Default.Favorite
        "valentine" -> Icons.Default.AutoAwesome
        "birthdays" -> Icons.Default.Cake
        else -> Icons.Default.Folder
    }
}

private fun getDrawableId(name: String?): Int? {
    return when (name) {
        "memory_first_meet" -> R.drawable.memory_first_meet
        "memory_propose" -> R.drawable.memory_propose
        "memory_valentine" -> R.drawable.memory_valentine
        "memory_birthday" -> R.drawable.memory_birthday
        else -> null
    }
}
