package com.example.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.ProfileEntity
import com.example.ui.theme.LovePinkPrimary
import com.example.ui.theme.LovePinkVariant
import com.example.ui.theme.LoveSoftBg
import com.example.util.LoveTimeCounter
import com.example.util.TimeUtils

@Composable
fun ProfilesScreen(
    profile: ProfileEntity,
    timeCounter: LoveTimeCounter,
    onEditProfile: () -> Unit,
    onOpenShareCard: () -> Unit,
    onHeartTap: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("profiles_screen_scroll"),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = 12.dp,
            bottom = 100.dp
        ),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Main Container Card matching user HTML structure (<div id="profile" class="tab-content">)
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("couple_profiles_container")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Header: <h2>👤 Couple Profiles</h2>
                    Text(
                        text = "👤 Couple Profiles",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = LovePinkPrimary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp)
                            .testTag("profiles_title_text")
                    )

                    HorizontalDivider(
                        color = MaterialTheme.colorScheme.background,
                        thickness = 2.dp,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    // Male Profile Card (<div class="profile-card">)
                    PartnerProfileCard(
                        name = profile.partner1,
                        nameId = "p1Name",
                        age = profile.partner1Age,
                        birthday = formatShortBday(profile.partner1Birthday),
                        address = profile.partner1Address,
                        addressId = "p1Addr",
                        avatarRes = R.drawable.avatar_male,
                        testTag = "male_profile_card"
                    )

                    // Connecting Love Icon
                    Box(
                        modifier = Modifier
                            .padding(vertical = 4.dp)
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(LovePinkPrimary)
                            .clickable { onHeartTap() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Favorite,
                            contentDescription = "Love Connection",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // Female Profile Card (<div class="profile-card">)
                    PartnerProfileCard(
                        name = profile.partner2,
                        nameId = "p2Name",
                        age = profile.partner2Age,
                        birthday = formatShortBday(profile.partner2Birthday),
                        address = profile.partner2Address,
                        addressId = "p2Addr",
                        avatarRes = R.drawable.avatar_female,
                        testTag = "female_profile_card"
                    )

                    Spacer(Modifier.height(16.dp))

                    // Relationship summary badge
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.background)
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "Together for ${timeCounter.totalDays} Days",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = LovePinkPrimary
                            )
                            Text(
                                text = "Anniversary: ${TimeUtils.formatDate(profile.startDateMillis)}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(Modifier.height(16.dp))

                    // Action Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = onEditProfile,
                            modifier = Modifier.weight(1f).testTag("edit_profiles_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = LovePinkPrimary),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Edit Profiles")
                        }

                        OutlinedButton(
                            onClick = onOpenShareCard,
                            modifier = Modifier.weight(1f).testTag("share_profiles_button"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Share Card")
                        }
                    }
                }
            }
        }
    }
}

// .profile-card matching user HTML:
// <div class="profile-card">
//     <h3 id="p1Name">Sajal Das</h3>
//     <p>Age: <strong>23</strong> Years | B'Day: 10 Jan</p>
//     <p>Address: <span id="p1Addr">India</span></p>
// </div>
@Composable
fun PartnerProfileCard(
    name: String,
    nameId: String,
    age: Int,
    birthday: String,
    address: String,
    addressId: String,
    avatarRes: Int,
    testTag: String
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.background),
        border = androidx.compose.foundation.BorderStroke(2.dp, LovePinkVariant),
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTag)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(15.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Circular Avatar (width: 65px; height: 65px; border: 3px solid var(--primary))
            Box(
                modifier = Modifier
                    .size(65.dp)
                    .clip(CircleShape)
                    .border(3.dp, LovePinkPrimary, CircleShape)
                    .background(Color(0xFFDDDDDD)),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = avatarRes),
                    contentDescription = name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(Modifier.height(10.dp))

            // <h3 id="...">Name</h3>
            Text(
                text = name,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = LovePinkPrimary,
                textAlign = TextAlign.Center,
                modifier = Modifier.testTag(nameId)
            )

            Spacer(Modifier.height(4.dp))

            // <p>Age: <strong>23</strong> Years | B'Day: 10 Jan</p>
            Text(
                text = buildAnnotatedString {
                    append("Age: ")
                    withStyle(style = SpanStyle(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)) {
                        append("$age")
                    }
                    append(" Years | B'Day: $birthday")
                },
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(3.dp))

            // <p>Address: <span id="...">India</span></p>
            Text(
                text = buildAnnotatedString {
                    append("Address: ")
                    withStyle(style = SpanStyle(fontWeight = FontWeight.Normal, color = MaterialTheme.colorScheme.onSurfaceVariant)) {
                        append(address)
                    }
                },
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.testTag(addressId)
            )
        }
    }
}

private fun formatShortBday(bday: String): String {
    return bday
        .replace("January", "Jan")
        .replace("February", "Feb")
        .replace("March", "Mar")
        .replace("April", "Apr")
        .replace("August", "Aug")
        .replace("September", "Sep")
        .replace("October", "Oct")
        .replace("November", "Nov")
        .replace("December", "Dec")
}
