package com.example.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.LoveDatabase
import com.example.data.LoveRepository
import com.example.data.MemoryEntity
import com.example.data.MilestoneEntity
import com.example.data.ProfileEntity
import com.example.data.VaultFolderEntity
import com.example.util.LoveTimeCounter
import com.example.util.TimeUtils
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class LoveQuote(
    val quote: String,
    val author: String
)

class LoveViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: LoveRepository
    val profile: StateFlow<ProfileEntity?>
    val milestones: StateFlow<List<MilestoneEntity>>
    val memories: StateFlow<List<MemoryEntity>>
    val vaultFolders: StateFlow<List<VaultFolderEntity>>

    private val prefs = application.getSharedPreferences("love_journey_prefs", Context.MODE_PRIVATE)

    private val _isDarkMode = MutableStateFlow(prefs.getBoolean("dark_mode", false))
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    private val _notificationsEnabled = MutableStateFlow(prefs.getBoolean("notifications_enabled", true))
    val notificationsEnabled: StateFlow<Boolean> = _notificationsEnabled.asStateFlow()

    private val _selectedFolder = MutableStateFlow<String?>(null)
    val selectedFolder: StateFlow<String?> = _selectedFolder.asStateFlow()

    private val _timeCounter = MutableStateFlow(LoveTimeCounter())
    val timeCounter: StateFlow<LoveTimeCounter> = _timeCounter.asStateFlow()

    private val _heartShowerEvent = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val heartShowerEvent: SharedFlow<Unit> = _heartShowerEvent.asSharedFlow()

    private val loveQuotes = listOf(
        LoveQuote("Whatever our souls are made of, his and mine are the same.", "Emily Brontë"),
        LoveQuote("I have found the one whom my soul loves.", "Song of Solomon"),
        LoveQuote("In all the world, there is no heart for me like yours.", "Maya Angelou"),
        LoveQuote("If I know what love is, it is because of you.", "Hermann Hesse"),
        LoveQuote("You are my today and all of my tomorrows.", "Leo Christopher"),
        LoveQuote("I love you not only for what you are, but for what I am when I am with you.", "Elizabeth Barrett Browning"),
        LoveQuote("To love and be loved is to feel the sun from both sides.", "David Viscott"),
        LoveQuote("Grow old along with me; the best is yet to be.", "Robert Browning")
    )

    private val _currentQuoteIndex = MutableStateFlow(0)
    val currentQuote: StateFlow<LoveQuote> = MutableStateFlow(loveQuotes[0]).apply {
        viewModelScope.launch {
            _currentQuoteIndex.collect { idx ->
                value = loveQuotes[idx % loveQuotes.size]
            }
        }
    }

    init {
        val database = LoveDatabase.getDatabase(application, viewModelScope)
        repository = LoveRepository(
            database.profileDao(),
            database.milestoneDao(),
            database.memoryDao(),
            database.vaultFolderDao()
        )

        profile = repository.profile.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            ProfileEntity()
        )

        milestones = repository.milestones.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        memories = repository.memories.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        vaultFolders = repository.vaultFolders.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        // Live second ticker
        viewModelScope.launch {
            while (isActive) {
                val currentProfile = profile.value ?: ProfileEntity()
                _timeCounter.value = TimeUtils.calculateLoveTime(
                    startEpochMillis = currentProfile.startDateMillis,
                    currentEpochMillis = System.currentTimeMillis()
                )
                delay(1000)
            }
        }
    }

    fun toggleDarkMode(enabled: Boolean) {
        _isDarkMode.value = enabled
        prefs.edit().putBoolean("dark_mode", enabled).apply()
    }

    fun toggleNotifications(enabled: Boolean) {
        _notificationsEnabled.value = enabled
        prefs.edit().putBoolean("notifications_enabled", enabled).apply()
    }

    fun selectFolder(folderName: String?) {
        _selectedFolder.value = folderName
    }

    fun nextQuote() {
        _currentQuoteIndex.value = (_currentQuoteIndex.value + 1) % loveQuotes.size
    }

    fun triggerHeartBurst() {
        _heartShowerEvent.tryEmit(Unit)
    }

    fun updateProfile(
        partner1: String,
        partner1Age: Int = 23,
        partner1Birthday: String = "10 January",
        partner1Address: String = "India",
        partner2: String = "Partner Name",
        partner2Age: Int = 21,
        partner2Birthday: String = "15 August",
        partner2Address: String = "India",
        startDateMillis: Long = 1704067200000L,
        status: String = "❤️ Relationship Home Screen ❤️",
        note: String = "Forever & Always"
    ) {
        viewModelScope.launch {
            repository.updateProfile(
                ProfileEntity(
                    id = 1,
                    partner1 = partner1.trim().ifEmpty { "Sajal Das" },
                    partner1Age = partner1Age,
                    partner1Birthday = partner1Birthday.trim().ifEmpty { "10 January" },
                    partner1Address = partner1Address.trim().ifEmpty { "India" },
                    partner2 = partner2.trim().ifEmpty { "Partner Name" },
                    partner2Age = partner2Age,
                    partner2Birthday = partner2Birthday.trim().ifEmpty { "15 August" },
                    partner2Address = partner2Address.trim().ifEmpty { "India" },
                    startDateMillis = startDateMillis,
                    coupleStatus = status,
                    customNote = note
                )
            )
            _timeCounter.value = TimeUtils.calculateLoveTime(startDateMillis)
        }
    }

    fun saveQuickProfileDetails(
        partner1: String,
        partner2: String,
        address: String
    ) {
        val current = profile.value ?: ProfileEntity()
        updateProfile(
            partner1 = partner1,
            partner1Age = current.partner1Age,
            partner1Birthday = current.partner1Birthday,
            partner1Address = address,
            partner2 = partner2,
            partner2Age = current.partner2Age,
            partner2Birthday = current.partner2Birthday,
            partner2Address = address,
            startDateMillis = current.startDateMillis,
            status = current.coupleStatus,
            note = current.customNote
        )
    }

    fun addMilestone(
        title: String,
        dateMillis: Long,
        isAnnual: Boolean,
        category: String,
        notes: String,
        iconName: String
    ) {
        viewModelScope.launch {
            repository.addMilestone(
                MilestoneEntity(
                    title = title,
                    dateMillis = dateMillis,
                    isAnnual = isAnnual,
                    category = category,
                    notes = notes,
                    iconName = iconName
                )
            )
        }
    }

    fun deleteMilestone(milestone: MilestoneEntity) {
        viewModelScope.launch {
            repository.deleteMilestone(milestone)
        }
    }

    fun addVaultFolder(name: String, subtitle: String = "📂 Yearly Archive") {
        viewModelScope.launch {
            repository.addVaultFolder(name.trim(), subtitle)
        }
    }

    fun addMemory(
        title: String,
        dateMillis: Long,
        description: String,
        folderName: String = "First Meet",
        tag: String = "Sweet Moment",
        imageUri: String? = null
    ) {
        viewModelScope.launch {
            repository.addMemory(
                MemoryEntity(
                    title = title,
                    dateMillis = dateMillis,
                    description = description,
                    folderName = folderName,
                    tag = tag,
                    imageUri = imageUri
                )
            )
        }
    }

    fun deleteMemory(memory: MemoryEntity) {
        viewModelScope.launch {
            repository.deleteMemory(memory)
        }
    }

    fun toggleMemoryFavorite(id: Long, current: Boolean) {
        viewModelScope.launch {
            repository.toggleMemoryFavorite(id, current)
        }
    }
}
