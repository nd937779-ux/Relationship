package com.example.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.MilestoneEntity
import com.example.data.ProfileEntity
import com.example.ui.theme.LovePinkPrimary
import com.example.ui.theme.LovePinkVariant
import com.example.util.LoveTimeCounter
import com.example.util.TimeUtils

@Composable
fun HomeScreen(
    profile: ProfileEntity,
    timeCounter: LoveTimeCounter,
    milestones: List<MilestoneEntity>,
    currentQuote: LoveQuote,
    onEditProfile: () -> Unit,
    onOpenShareCard: () -> Unit,
    onOpenAddMilestone: () -> Unit,
    onNavigateMilestones: () -> Unit,
    onNavigateProfiles: () -> Unit,
    onNextQuote: () -> Unit,
    onHeartTap: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Pulse animation for the heart icon
    val infiniteTransition = rememberInfiniteTransition(label = "heartPulse")
    val heartScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.18f,
        animationSpec = infiniteRepeatable(
            animation = tween(650),
            repeatMode = RepeatMode.Reverse
        ),
        label = "heartScale"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("home_screen_scroll"),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = 12.dp,
            bottom = 100.dp
        ),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Couple Header Card (Sajal & Partner, Avatars, Status)
        item {
            ElevatedCard(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.elevatedCardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateProfiles() }
                    .testTag("couple_header_card")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = onOpenShareCard,
                            modifier = Modifier.testTag("share_journey_button")
                        ) {
                            Icon(
                                Icons.Default.Share,
                                contentDescription = "Share Card",
                                tint = LovePinkPrimary
                            )
                        }

                        // Center Avatars with Pulsing Heart
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .border(2.dp, LovePinkPrimary, CircleShape)
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.avatar_male),
                                    contentDescription = profile.partner1,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }

                            Icon(
                                Icons.Default.Favorite,
                                contentDescription = "Heart",
                                tint = LovePinkPrimary,
                                modifier = Modifier
                                    .padding(horizontal = 8.dp)
                                    .size(20.dp)
                                    .scale(heartScale)
                                    .clickable { onHeartTap() }
                            )

                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .border(2.dp, LovePinkPrimary, CircleShape)
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.avatar_female),
                                    contentDescription = profile.partner2,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }

                        IconButton(
                            onClick = onEditProfile,
                            modifier = Modifier.testTag("edit_profile_button")
                        ) {
                            Icon(
                                Icons.Default.Edit,
                                contentDescription = "Edit Names & Date",
                                tint = LovePinkPrimary
                            )
                        }
                    }

                    Spacer(Modifier.height(10.dp))

                    Text(
                        text = "${profile.partner1} & ${profile.partner2}",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = LovePinkPrimary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.testTag("couple_names_text")
                    )

                    Spacer(Modifier.height(4.dp))

                    Text(
                        text = profile.coupleStatus,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        // Live Relationship Timer Card (.timer-card matching user HTML & CSS)
        // .timer-card { background: linear-gradient(135deg, #ff4b6e, #ff758c); color: white; padding: 20px; border-radius: 12px; margin-bottom: 20px; }
        // .timer-card h3 { font-size: 15px; margin-bottom: 10px; font-weight: 400; }
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("timer_card")
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFFFF4B6E), // var(--primary)
                                    Color(0xFFFF758C)  // var(--secondary)
                                )
                            )
                        )
                        .clickable { onHeartTap() }
                        .padding(20.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // h3: We Have Been Together For
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.padding(bottom = 8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Favorite,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier
                                    .size(16.dp)
                                    .scale(heartScale)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = "We Have Been Together For",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Normal,
                                color = Color.White,
                                textAlign = TextAlign.Center
                            )
                        }

                        // Total Days Hero Counter
                        Text(
                            text = "${timeCounter.totalDays} Days",
                            fontSize = 30.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White,
                            modifier = Modifier.testTag("total_days_text")
                        )

                        Text(
                            text = "Since ${TimeUtils.formatDate(profile.startDateMillis)}",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.85f),
                            modifier = Modifier.padding(bottom = 12.dp)
                        )

                        // .grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; }
                        Column(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                TimerBox(value = "${timeCounter.years}", label = "Years", testTag = "timer_years", modifier = Modifier.weight(1f))
                                TimerBox(value = "${timeCounter.months}", label = "Months", testTag = "timer_months", modifier = Modifier.weight(1f))
                                TimerBox(value = "${timeCounter.days}", label = "Days", testTag = "timer_days", modifier = Modifier.weight(1f))
                            }
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                TimerBox(value = "${timeCounter.hours}", label = "Hours", testTag = "timer_hours", modifier = Modifier.weight(1f))
                                TimerBox(value = "${timeCounter.minutes}", label = "Mins", testTag = "timer_mins", modifier = Modifier.weight(1f))
                                TimerBox(value = "${timeCounter.seconds}", label = "Secs", testTag = "timer_secs", modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }

        // Daily Love Spark Quote Card
        item {
            ElevatedCard(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.elevatedCardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth().testTag("quote_card")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = LovePinkPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                "Daily Love Spark",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = LovePinkPrimary
                            )
                        }

                        IconButton(
                            onClick = onNextQuote,
                            modifier = Modifier.size(28.dp).testTag("next_quote_button")
                        ) {
                            Icon(
                                Icons.Default.Refresh,
                                contentDescription = "New Quote",
                                tint = LovePinkPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    Spacer(Modifier.height(6.dp))

                    Text(
                        text = "“${currentQuote.quote}”",
                        fontSize = 13.sp,
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                        color = MaterialTheme.colorScheme.onSurface,
                        lineHeight = 18.sp
                    )

                    Spacer(Modifier.height(4.dp))

                    Text(
                        text = "— ${currentQuote.author}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.End,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // Special Milestones Section (.milestones h2 matching user HTML)
        // .milestones h2 { font-size: 15px; color: var(--primary); margin-bottom: 10px; border-bottom: 1px solid #eee; padding-bottom: 5px; }
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "✨ Special Milestones",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = LovePinkPrimary,
                        modifier = Modifier.testTag("special_milestones_heading")
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        FilledTonalButton(
                            onClick = onOpenAddMilestone,
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("home_add_milestone_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Add", fontSize = 11.sp)
                        }

                        IconButton(
                            onClick = onNavigateMilestones,
                            modifier = Modifier.size(32.dp).testTag("home_view_all_milestones_button")
                        ) {
                            Icon(
                                Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = "View all",
                                tint = LovePinkPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                HorizontalDivider(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    thickness = 1.dp,
                    modifier = Modifier.padding(top = 4.dp, bottom = 4.dp)
                )
            }
        }

        // Milestone items matching .m-item:
        // .m-item { background: #fafafa; padding: 10px; border-radius: 6px; margin-bottom: 6px; display: flex; justify-content: space-between; font-size: 13px; border-left: 3px solid var(--primary); }
        // <div class="m-item"><span>First Meet</span><strong>14 Feb 2024</strong></div>
        // <div class="m-item"><span>First Propose</span><strong>20 Mar 2024</strong></div>
        // <div class="m-item"><span>Valentine's Day</span><strong>14 Feb</strong></div>
        if (milestones.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(6.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(20.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text(
                            "No milestones yet. Tap '+ Add' to save your special dates!",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(milestones.take(4), key = { it.id }) { milestone ->
                MilestoneItemCard(milestone = milestone)
            }
        }
    }
}

// .m-item matching user CSS
@Composable
fun MilestoneItemCard(milestone: MilestoneEntity) {
    val dateLabel = if (milestone.isAnnual || milestone.title.contains("Valentine", ignoreCase = true)) {
        TimeUtils.formatShortDate(milestone.dateMillis)
    } else {
        TimeUtils.formatDate(milestone.dateMillis)
    }

    val diffInfo = TimeUtils.getDaysDifferenceLabel(milestone.dateMillis, milestone.isAnnual)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(MaterialTheme.colorScheme.surface)
            .testTag("milestone_item_${milestone.id}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // border-left: 3px solid var(--primary);
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height(44.dp)
                    .background(LovePinkPrimary)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // <span>First Meet</span>
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = milestone.title,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Normal,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (diffInfo.first.isNotBlank()) {
                        Text(
                            text = diffInfo.first,
                            fontSize = 10.sp,
                            color = if (diffInfo.second) LovePinkPrimary else MaterialTheme.colorScheme.outline
                        )
                    }
                }

                // <strong>14 Feb 2024</strong>
                Text(
                    text = dateLabel,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

// .box matching user CSS
// .box { background: rgba(255, 255, 255, 0.2); padding: 8px; border-radius: 6px; }
// .box span { font-size: 16px; font-weight: bold; display: block; }
// .box small { font-size: 9px; text-transform: uppercase; }
@Composable
private fun TimerBox(
    value: String,
    label: String,
    testTag: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(Color.White.copy(alpha = 0.2f))
            .padding(vertical = 8.dp, horizontal = 4.dp)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            // span
            Text(
                text = value,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            // small
            Text(
                text = label.uppercase(),
                fontSize = 9.sp,
                fontWeight = FontWeight.Normal,
                letterSpacing = 0.5.sp,
                color = Color.White.copy(alpha = 0.9f)
            )
        }
    }
}
