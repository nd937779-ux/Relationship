package com.example.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ProfileEntity
import com.example.ui.theme.LovePinkPrimary
import com.example.ui.theme.LovePinkVariant
import com.example.ui.theme.LoveSoftBg

@Composable
fun SettingsScreen(
    profile: ProfileEntity,
    isDarkMode: Boolean,
    notificationsEnabled: Boolean,
    onSaveProfileDetails: (partner1: String, partner2: String, address: String) -> Unit,
    onToggleDarkMode: (Boolean) -> Unit,
    onToggleNotifications: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    var p1Name by remember(profile.partner1) { mutableStateOf(profile.partner1) }
    var p2Name by remember(profile.partner2) { mutableStateOf(profile.partner2) }
    var address by remember(profile.partner1Address) { mutableStateOf(profile.partner1Address) }

    var showLogoutDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("settings_screen_scroll"),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = 12.dp,
            bottom = 100.dp
        ),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            // Main Container Card matching user HTML structure
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("settings_container")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    // Header: ⚙️ App Settings
                    Text(
                        text = "⚙️ App Settings",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = LovePinkPrimary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp)
                            .testTag("settings_title_text")
                    )

                    HorizontalDivider(
                        color = MaterialTheme.colorScheme.background,
                        thickness = 2.dp,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    // Profile & Address Edit Box (.setting-box)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.background)
                            .padding(12.dp)
                            .testTag("setting_box_profile")
                    ) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = "Edit Profile Details",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = LovePinkPrimary,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )

                            Text(
                                text = "Your Name:",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            OutlinedTextField(
                                value = p1Name,
                                onValueChange = { p1Name = it },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 4.dp, bottom = 10.dp)
                                    .testTag("settings_input_name1"),
                                shape = RoundedCornerShape(6.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                                    unfocusedContainerColor = MaterialTheme.colorScheme.surface
                                )
                            )

                            Text(
                                text = "Partner Name:",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            OutlinedTextField(
                                value = p2Name,
                                onValueChange = { p2Name = it },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 4.dp, bottom = 10.dp)
                                    .testTag("settings_input_name2"),
                                shape = RoundedCornerShape(6.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                                    unfocusedContainerColor = MaterialTheme.colorScheme.surface
                                )
                            )

                            Text(
                                text = "Address:",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            OutlinedTextField(
                                value = address,
                                onValueChange = { address = it },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 4.dp, bottom = 10.dp)
                                    .testTag("settings_input_address"),
                                shape = RoundedCornerShape(6.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                                    unfocusedContainerColor = MaterialTheme.colorScheme.surface
                                )
                            )

                            // Save Changes Button (.btn-save)
                            Button(
                                onClick = {
                                    onSaveProfileDetails(p1Name, p2Name, address)
                                    Toast.makeText(
                                        context,
                                        "Settings saved!\nName: $p1Name & $p2Name\nAddress: $address",
                                        Toast.LENGTH_LONG
                                    ).show()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = LovePinkPrimary),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(
                                    horizontal = 14.dp,
                                    vertical = 8.dp
                                ),
                                modifier = Modifier.testTag("btn_save_settings")
                            ) {
                                Text(
                                    text = "Save Changes",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    // Setting Item: Notification System
                    SettingItem(
                        iconAndTitle = "🔔 Notification System",
                        testTag = "setting_item_notif"
                    ) {
                        Switch(
                            checked = notificationsEnabled,
                            onCheckedChange = { isChecked ->
                                onToggleNotifications(isChecked)
                                val msg = if (isChecked) "Notifications Enabled! 🔔" else "Notifications Disabled! 🔕"
                                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = LovePinkPrimary
                            ),
                            modifier = Modifier.testTag("notif_toggle_switch")
                        )
                    }

                    Spacer(Modifier.height(8.dp))

                    // Setting Item: Dark Mode
                    SettingItem(
                        iconAndTitle = "🌙 Dark Mode",
                        testTag = "setting_item_dark"
                    ) {
                        Switch(
                            checked = isDarkMode,
                            onCheckedChange = { isChecked ->
                                onToggleDarkMode(isChecked)
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = LovePinkPrimary
                            ),
                            modifier = Modifier.testTag("dark_toggle_switch")
                        )
                    }

                    Spacer(Modifier.height(8.dp))

                    // Setting Item: App Version
                    SettingItem(
                        iconAndTitle = "📌 App Version",
                        testTag = "setting_item_version"
                    ) {
                        Text(
                            text = "v1.0.0",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = LovePinkPrimary
                        )
                    }

                    Spacer(Modifier.height(8.dp))

                    // Setting Item: Log Out
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isDarkMode) Color(0xFF381E24) else Color(0xFFFFE3E8))
                            .clickable { showLogoutDialog = true }
                            .padding(horizontal = 15.dp, vertical = 14.dp)
                            .testTag("setting_item_logout")
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "🚪 Log Out",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFD9534F)
                            )
                            Text(
                                text = "→",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFD9534F)
                            )
                        }
                    }
                }
            }
        }
    }

    // Logout Confirmation Dialog
    if (showLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutDialog = false },
            title = {
                Text(text = "Log Out", style = MaterialTheme.typography.titleLarge)
            },
            text = {
                Text(
                    text = "Are you sure you want to log out of Our Love Journey?",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showLogoutDialog = false
                        Toast.makeText(context, "Logged out successfully.", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD9534F)),
                    modifier = Modifier.testTag("confirm_logout_button")
                ) {
                    Text("Log Out", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showLogoutDialog = false },
                    modifier = Modifier.testTag("cancel_logout_button")
                ) {
                    Text("Cancel")
                }
            }
        )
    }
}

// Reusable Setting Item matching CSS:
// .setting-item { background: var(--bg); padding: 12px 15px; border-radius: 8px; margin-bottom: 8px; display: flex; justify-content: space-between; align-items: center; font-size: 14px; border-left: 4px solid var(--primary); }
@Composable
private fun SettingItem(
    iconAndTitle: String,
    testTag: String,
    action: @Composable () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.background)
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left 4px accent border (border-left: 4px solid var(--primary);)
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height(48.dp)
                    .background(LovePinkPrimary)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = iconAndTitle,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurface
                )

                action()
            }
        }
    }
}
