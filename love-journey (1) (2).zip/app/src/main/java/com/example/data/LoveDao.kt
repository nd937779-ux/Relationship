package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ProfileDao {
    @Query("SELECT * FROM profile_table WHERE id = 1 LIMIT 1")
    fun getProfile(): Flow<ProfileEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(profile: ProfileEntity)
}

@Dao
interface MilestoneDao {
    @Query("SELECT * FROM milestones_table ORDER BY dateMillis ASC")
    fun getAllMilestones(): Flow<List<MilestoneEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(milestone: MilestoneEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(milestones: List<MilestoneEntity>)

    @Update
    suspend fun update(milestone: MilestoneEntity)

    @Delete
    suspend fun delete(milestone: MilestoneEntity)

    @Query("SELECT COUNT(*) FROM milestones_table")
    suspend fun count(): Int
}

@Dao
interface VaultFolderDao {
    @Query("SELECT * FROM vault_folders_table ORDER BY id ASC")
    fun getAllFolders(): Flow<List<VaultFolderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(folder: VaultFolderEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(folders: List<VaultFolderEntity>)

    @Delete
    suspend fun delete(folder: VaultFolderEntity)

    @Query("SELECT COUNT(*) FROM vault_folders_table")
    suspend fun count(): Int
}

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memories_table ORDER BY dateMillis DESC")
    fun getAllMemories(): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memories_table WHERE folderName = :folderName ORDER BY dateMillis DESC")
    fun getMemoriesByFolder(folderName: String): Flow<List<MemoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(memory: MemoryEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(memories: List<MemoryEntity>)

    @Delete
    suspend fun delete(memory: MemoryEntity)

    @Query("UPDATE memories_table SET isFavorite = :isFav WHERE id = :id")
    suspend fun updateFavorite(id: Long, isFav: Boolean)

    @Query("SELECT COUNT(*) FROM memories_table")
    suspend fun count(): Int
}
