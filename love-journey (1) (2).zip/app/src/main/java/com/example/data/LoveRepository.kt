package com.example.data

import kotlinx.coroutines.flow.Flow

class LoveRepository(
    private val profileDao: ProfileDao,
    private val milestoneDao: MilestoneDao,
    private val memoryDao: MemoryDao,
    private val vaultFolderDao: VaultFolderDao
) {
    val profile: Flow<ProfileEntity?> = profileDao.getProfile()
    val milestones: Flow<List<MilestoneEntity>> = milestoneDao.getAllMilestones()
    val memories: Flow<List<MemoryEntity>> = memoryDao.getAllMemories()
    val vaultFolders: Flow<List<VaultFolderEntity>> = vaultFolderDao.getAllFolders()

    suspend fun updateProfile(profile: ProfileEntity) {
        profileDao.insertOrUpdate(profile)
    }

    suspend fun addMilestone(milestone: MilestoneEntity): Long {
        return milestoneDao.insert(milestone)
    }

    suspend fun deleteMilestone(milestone: MilestoneEntity) {
        milestoneDao.delete(milestone)
    }

    suspend fun addVaultFolder(name: String, subtitle: String = "📂 Yearly Archive"): Long {
        return vaultFolderDao.insert(VaultFolderEntity(name = name, subtitle = subtitle))
    }

    suspend fun deleteVaultFolder(folder: VaultFolderEntity) {
        vaultFolderDao.delete(folder)
    }

    suspend fun addMemory(memory: MemoryEntity): Long {
        return memoryDao.insert(memory)
    }

    suspend fun deleteMemory(memory: MemoryEntity) {
        memoryDao.delete(memory)
    }

    suspend fun toggleMemoryFavorite(id: Long, currentFav: Boolean) {
        memoryDao.updateFavorite(id, !currentFav)
    }
}
