package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "profile_table")
data class ProfileEntity(
    @PrimaryKey val id: Int = 1,
    val partner1: String = "Sajal Das",
    val partner1Age: Int = 23,
    val partner1Birthday: String = "10 January",
    val partner1Address: String = "India",
    val partner2: String = "Partner Name",
    val partner2Age: Int = 21,
    val partner2Birthday: String = "15 August",
    val partner2Address: String = "India",
    val startDateMillis: Long = 1704067200000L, // Jan 1, 2024 00:00:00 UTC
    val coupleStatus: String = "❤️ Relationship Home Screen ❤️",
    val customNote: String = "Forever & Always"
)

@Entity(tableName = "milestones_table")
data class MilestoneEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val dateMillis: Long,
    val isAnnual: Boolean = false,
    val category: String = "Special",
    val notes: String = "",
    val iconName: String = "favorite"
)

@Entity(tableName = "vault_folders_table")
data class VaultFolderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val subtitle: String = "📂 Yearly Archive",
    val iconName: String = "folder"
)

@Entity(tableName = "memories_table")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val dateMillis: Long,
    val description: String,
    val folderName: String = "First Meet",
    val tag: String = "Sweet Moment",
    val imageUri: String? = null,
    val drawableResName: String? = null,
    val isFavorite: Boolean = false
)
