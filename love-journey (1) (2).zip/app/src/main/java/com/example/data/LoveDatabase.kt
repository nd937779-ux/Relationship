package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [ProfileEntity::class, MilestoneEntity::class, MemoryEntity::class, VaultFolderEntity::class],
    version = 3,
    exportSchema = false
)
abstract class LoveDatabase : RoomDatabase() {
    abstract fun profileDao(): ProfileDao
    abstract fun milestoneDao(): MilestoneDao
    abstract fun memoryDao(): MemoryDao
    abstract fun vaultFolderDao(): VaultFolderDao

    companion object {
        @Volatile
        private var INSTANCE: LoveDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): LoveDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    LoveDatabase::class.java,
                    "love_journey_db"
                )
                    .fallbackToDestructiveMigration(true)
                    .addCallback(LoveDatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class LoveDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateInitialData(database)
                }
            }
        }

        private suspend fun populateInitialData(database: LoveDatabase) {
            val profileDao = database.profileDao()
            val milestoneDao = database.milestoneDao()
            val memoryDao = database.memoryDao()
            val folderDao = database.vaultFolderDao()

            // Default profile matching user prompt
            profileDao.insertOrUpdate(
                ProfileEntity(
                    id = 1,
                    partner1 = "Sajal Das",
                    partner1Age = 23,
                    partner1Birthday = "10 January",
                    partner1Address = "India",
                    partner2 = "Partner Name",
                    partner2Age = 21,
                    partner2Birthday = "15 August",
                    partner2Address = "India",
                    startDateMillis = 1704067200000L, // 2024-01-01 00:00:00 UTC
                    coupleStatus = "❤️ Relationship Home Screen ❤️",
                    customNote = "Every moment with you is a gift."
                )
            )

            // Special Milestones matching user HTML:
            milestoneDao.insertAll(
                listOf(
                    MilestoneEntity(
                        title = "First Meet",
                        dateMillis = 1707868800000L, // 14 Feb 2024
                        isAnnual = false,
                        category = "First Date",
                        notes = "The sparks and nervous smiles when our eyes first met ✨",
                        iconName = "favorite"
                    ),
                    MilestoneEntity(
                        title = "First Propose",
                        dateMillis = 1710892800000L, // 20 Mar 2024
                        isAnnual = false,
                        category = "Proposal",
                        notes = "The unforgettable moment with heartbeats skipping a beat 💍",
                        iconName = "ring"
                    ),
                    MilestoneEntity(
                        title = "Valentine's Day",
                        dateMillis = 1739491200000L, // 14 Feb 2025
                        isAnnual = true,
                        category = "Celebration",
                        notes = "Annual celebration of our love and warmth 🌹",
                        iconName = "celebration"
                    ),
                    MilestoneEntity(
                        title = "1st Anniversary",
                        dateMillis = 1735689600000L, // 01 Jan 2025
                        isAnnual = true,
                        category = "Anniversary",
                        notes = "Celebrating our first 365 days of endless memories 🎉",
                        iconName = "cake"
                    )
                )
            )

            // Yearly Memory Vault Folders matching user HTML:
            folderDao.insertAll(
                listOf(
                    VaultFolderEntity(name = "First Meet", subtitle = "📂 Yearly Archive", iconName = "favorite"),
                    VaultFolderEntity(name = "Propose", subtitle = "📂 Yearly Archive", iconName = "ring"),
                    VaultFolderEntity(name = "Valentine", subtitle = "📂 Yearly Archive", iconName = "celebration"),
                    VaultFolderEntity(name = "Birthdays", subtitle = "📂 Yearly Archive", iconName = "cake")
                )
            )

            // Initial Memories with artwork
            memoryDao.insertAll(
                listOf(
                    MemoryEntity(
                        title = "First Coffee & Endless Laughs",
                        dateMillis = 1708041600000L, // 16 Feb 2024
                        description = "We talked for three hours at the cozy café and didn't even notice the café was closing.",
                        folderName = "First Meet",
                        tag = "First Date",
                        drawableResName = "memory_first_meet",
                        isFavorite = true
                    ),
                    MemoryEntity(
                        title = "Under The Twilight Sky",
                        dateMillis = 1710892800000L, // 20 Mar 2024
                        description = "Under the glowing fairy lights with sunset reflections, the proposal words were whispered.",
                        folderName = "Propose",
                        tag = "Proposal",
                        drawableResName = "memory_propose",
                        isFavorite = true
                    ),
                    MemoryEntity(
                        title = "Red Balloons & Sweet Flowers",
                        dateMillis = 1707868800000L, // 14 Feb 2024
                        description = "Walking hand in hand carrying heart-shaped balloons through the festive avenue.",
                        folderName = "Valentine",
                        tag = "Celebration",
                        drawableResName = "memory_valentine",
                        isFavorite = true
                    ),
                    MemoryEntity(
                        title = "Candles, Cake & Warm Smiles",
                        dateMillis = 1704844800000L, // 10 Jan 2024
                        description = "Blowing candles together wishing for endless years of joy and adventures.",
                        folderName = "Birthdays",
                        tag = "Birthday",
                        drawableResName = "memory_birthday",
                        isFavorite = true
                    )
                )
            )
        }
    }
}
