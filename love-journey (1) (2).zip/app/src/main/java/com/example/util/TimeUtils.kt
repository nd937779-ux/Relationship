package com.example.util

import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.Period
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale

data class LoveTimeCounter(
    val years: Long = 0,
    val months: Long = 0,
    val days: Long = 0,
    val hours: Long = 0,
    val minutes: Long = 0,
    val seconds: Long = 0,
    val totalDays: Long = 0,
    val isFuture: Boolean = false
)

object TimeUtils {
    private val dateFormatter = DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.getDefault())
    private val shortDateFormatter = DateTimeFormatter.ofPattern("dd MMM", Locale.getDefault())

    fun calculateLoveTime(startEpochMillis: Long, currentEpochMillis: Long = System.currentTimeMillis()): LoveTimeCounter {
        val zone = ZoneId.systemDefault()
        val startDateTime = LocalDateTime.ofInstant(Instant.ofEpochMilli(startEpochMillis), zone)
        val currentDateTime = LocalDateTime.ofInstant(Instant.ofEpochMilli(currentEpochMillis), zone)

        if (currentDateTime.isBefore(startDateTime)) {
            // Future target countdown
            val totalSeconds = ChronoUnit.SECONDS.between(currentDateTime, startDateTime)
            val days = totalSeconds / (24 * 3600)
            val hours = (totalSeconds % (24 * 3600)) / 3600
            val minutes = (totalSeconds % 3600) / 60
            val seconds = totalSeconds % 60
            val years = days / 365
            val months = (days % 365) / 30
            val remDays = days % 30
            return LoveTimeCounter(
                years = years,
                months = months,
                days = remDays,
                hours = hours,
                minutes = minutes,
                seconds = seconds,
                totalDays = days,
                isFuture = true
            )
        }

        // Past start date count up
        val totalDays = ChronoUnit.DAYS.between(startDateTime.toLocalDate(), currentDateTime.toLocalDate())

        // Calculate calendar accurate years, months, days
        var tempDateTime = startDateTime
        var years = ChronoUnit.YEARS.between(tempDateTime, currentDateTime)
        tempDateTime = tempDateTime.plusYears(years)

        var months = ChronoUnit.MONTHS.between(tempDateTime, currentDateTime)
        tempDateTime = tempDateTime.plusMonths(months)

        var days = ChronoUnit.DAYS.between(tempDateTime, currentDateTime)
        tempDateTime = tempDateTime.plusDays(days)

        var hours = ChronoUnit.HOURS.between(tempDateTime, currentDateTime)
        tempDateTime = tempDateTime.plusHours(hours)

        var minutes = ChronoUnit.MINUTES.between(tempDateTime, currentDateTime)
        tempDateTime = tempDateTime.plusMinutes(minutes)

        var seconds = ChronoUnit.SECONDS.between(tempDateTime, currentDateTime)

        return LoveTimeCounter(
            years = years,
            months = months,
            days = days,
            hours = hours,
            minutes = minutes,
            seconds = seconds,
            totalDays = totalDays,
            isFuture = false
        )
    }

    fun formatDate(epochMillis: Long): String {
        val localDate = Instant.ofEpochMilli(epochMillis).atZone(ZoneId.systemDefault()).toLocalDate()
        return localDate.format(dateFormatter)
    }

    fun formatShortDate(epochMillis: Long): String {
        val localDate = Instant.ofEpochMilli(epochMillis).atZone(ZoneId.systemDefault()).toLocalDate()
        return localDate.format(shortDateFormatter)
    }

    fun getDaysDifferenceLabel(targetEpochMillis: Long, isAnnual: Boolean = false): Pair<String, Boolean> {
        val zone = ZoneId.systemDefault()
        val today = LocalDate.now(zone)
        var targetDate = Instant.ofEpochMilli(targetEpochMillis).atZone(zone).toLocalDate()

        if (isAnnual) {
            // Shift to this year or next year
            var annualThisYear = targetDate.withYear(today.year)
            if (annualThisYear.isBefore(today)) {
                annualThisYear = annualThisYear.plusYears(1)
            }
            targetDate = annualThisYear
        }

        val daysDiff = ChronoUnit.DAYS.between(today, targetDate)
        return when {
            daysDiff == 0L -> Pair("Today! 🎉", true)
            daysDiff == 1L -> Pair("Tomorrow! 💖", true)
            daysDiff > 1L -> Pair("In $daysDiff days", true)
            daysDiff == -1L -> Pair("Yesterday", false)
            else -> Pair("${Math.abs(daysDiff)} days ago", false)
        }
    }
}
